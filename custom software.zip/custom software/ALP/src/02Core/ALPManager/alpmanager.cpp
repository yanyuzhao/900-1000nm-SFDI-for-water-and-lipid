#include "alpmanager.h"

ALPManager::ALPManager()
{

}

ALPManager::~ALPManager()
{

}
