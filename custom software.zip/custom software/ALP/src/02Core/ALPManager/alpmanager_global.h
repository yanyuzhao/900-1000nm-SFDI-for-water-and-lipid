#ifndef ALPMANAGER_GLOBAL_H
#define ALPMANAGER_GLOBAL_H

#include <QtCore/qglobal.h>

#ifdef ALPMANAGER_LIB
# define ALPMANAGER_EXPORT Q_DECL_EXPORT
#else
# define ALPMANAGER_EXPORT Q_DECL_IMPORT
#endif

#endif // ALPMANAGER_GLOBAL_H
