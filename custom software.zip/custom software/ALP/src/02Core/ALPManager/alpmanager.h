#ifndef ALPMANAGER_H
#define ALPMANAGER_H

#include "alpmanager_global.h"

class ALPMANAGER_EXPORT ALPManager
{
public:
	ALPManager();
	~ALPManager();

private:

};

#endif // ALPMANAGER_H
