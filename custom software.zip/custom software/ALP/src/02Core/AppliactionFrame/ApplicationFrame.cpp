#include "ApplicationFrame.h"

#include <osg/OperationThread>
#include <osgDB/ReadFile>
#include <osgDB/ConvertUTF>



namespace Frame
{
	ApplicationFrame::ApplicationFrame()
		:_mainWindow(NULL)
	{
		_pluginManager = new PluginManager(this);

	}
	ApplicationFrame::~ApplicationFrame(void)
	{
	}

	void ApplicationFrame::InitApplication(std::string info)
	{
		std::string infotext = info; 
		_pluginManager->LoadPlugin();
	}

	void * ApplicationFrame::GetMainWindow()
	{
		return _mainWindow;
	}

	void ApplicationFrame::SetMainWindow(void * mainWindow)
	{
		_mainWindow = mainWindow;
	}

	void ApplicationFrame::Update()
	{

	}



	void ApplicationFrame::ClearApplication()
	{
		_pluginManager->DestoryPlugin();
	}





	PluginManager* ApplicationFrame::GetPluginManager()
	{
		return _pluginManager;
	}



}
