#ifndef APPLIACTIONFRAME_H
#define APPLIACTIONFRAME_H

#include "appliactionframe_global.h"

class APPLIACTIONFRAME_EXPORT AppliactionFrame
{
public:
	AppliactionFrame();
	~AppliactionFrame();

private:

};

#endif // APPLIACTIONFRAME_H
