#include "appliactionframe.h"

AppliactionFrame::AppliactionFrame()
{

}

AppliactionFrame::~AppliactionFrame()
{

}
