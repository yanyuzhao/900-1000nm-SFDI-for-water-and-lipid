#include "PluginManager.h"
#include <XMLCommon/XmlOperate.h>


namespace Frame
{
	typedef Plugin*(* CreatePlugin)(void);

	PluginManager::PluginManager(ApplicationFrame*  appFrame)
		:_appFrame(appFrame)
	{
		
	}


	PluginManager::~PluginManager(void)
	{
		DestoryPlugin();
		_dlls.clear();
	}

	void PluginManager::LoadPlugin()
	{
		osg::ref_ptr<XmlComm::XmlNode> xmlNode = XmlComm::XmlTool::LoadFile("./config/PluginCfg.xml");
		if ( xmlNode == NULL || !xmlNode->GetChildren().size())
		{
			//G_ERROR("��������ļ���./config/PluginCfg.xml������ʧ�ܣ�");
			return; 
		}

		const XmlComm::XmlNodeList& xmlNodeList = xmlNode->GetChildren().at(0)->GetChildren();
		XmlComm::XmlNodeList::const_iterator itrXmlNode =  xmlNodeList.begin();
		while( itrXmlNode != xmlNodeList.end())
		{
			std::string value; 
			bool flag = (*itrXmlNode)->GetValue("pluginname",value);
			if ( flag )
			{
#ifdef _DEBUG
				value += "d";
#endif
				value+=".dll";
				osg::ref_ptr<osgDB::DynamicLibrary> dll = osgDB::DynamicLibrary::loadLibrary(value); 
				bool flag = false;
				if ( dll )
				{
					_dlls.push_back(dll);
					CreatePlugin func =(CreatePlugin ) dll->getProcAddress("CreatePlugin");
					if ( func )
					{
						Plugin* plugin = (*func)();
						if ( plugin )
						{
							_plugins.push_back(plugin);
						}
						flag = true;
					}
				}

				if ( !flag )
				{
					//G_ALWAYS("�����"+value+"������ʧ��!");
				}
			}
			++itrXmlNode;
		}

		std::vector< osg::ref_ptr<Plugin> >::iterator itrPlugin = _plugins.begin();
		while( itrPlugin != _plugins.end() )
		{
			(*itrPlugin)->Create(_appFrame);
			++itrPlugin;
		}
	}

	void PluginManager::DestoryPlugin()
	{
		std::vector< osg::ref_ptr<Plugin> >::iterator itrPlugin = _plugins.begin();
		while( itrPlugin != _plugins.end() )
		{
			(*itrPlugin)->Destroy();
			++itrPlugin;
		}
		_plugins.clear();
	}

	void PluginManager::SetMessage(std::string messageType,void* messageData)
	{
		std::vector< osg::ref_ptr<Plugin> >::iterator itrPlugin = _plugins.begin();
		while( itrPlugin != _plugins.end() )
		{
			if ( (*itrPlugin)->OnMessage(messageType,messageData) )
			{
				return;
			}
			++itrPlugin;
		}
	}
}