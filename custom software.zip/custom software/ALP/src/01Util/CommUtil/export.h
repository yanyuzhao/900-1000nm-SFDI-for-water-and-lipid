#ifndef COMMUTIL_H
#define COMMUTIL_H

// define USE_DEPRECATED_API is used to include in API which is being fazed out
// if you can compile your apps with this turned off you are
// well placed for compatibility with future versions.
#define USE_DEPRECATED_API

// disable VisualStudio warnings
#if defined(_MSC_VER) && defined(OSG_DISABLE_MSVC_WARNINGS)
#pragma warning( disable : 4244 )
#pragma warning( disable : 4251 )
#pragma warning( disable : 4275 )
#pragma warning( disable : 4512 )
#pragma warning( disable : 4267 )
#pragma warning( disable : 4702 )
#pragma warning( disable : 4511 )
#endif

#if defined(_MSC_VER) || defined(__CYGWIN__) || defined(__MINGW32__) || defined( __BCPLUSPLUS__)  || defined( __MWERKS__)
#  if defined( CommUtil_LIBRARY_STATIC )
#    define CommEffect_EXPORT
#  elif defined( CommEffect_EXPORTS )
#    define CommEffect_EXPORT   __declspec(dllexport)
#  else
#    define CommEffect_EXPORT   __declspec(dllimport)
#  endif
#else
#  define CommEffect_EXPORT
#endif


#endif // RITTANBSEPLUGIN_GLOBAL_H
