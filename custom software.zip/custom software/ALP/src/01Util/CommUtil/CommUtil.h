/********************************************************************
	created:	2017/11/29
	created:	29:11:2017   11:22
	author:		�� ��
	
	purpose:	���ͨ������
*********************************************************************/
#ifndef COMMUTIL_H__
#define COMMUTIL_H__
#include "export.h"
#include <string>

namespace ALP
{
	class CommEffect_EXPORT CommUtil 
	{
	public:
		CommUtil();

		~CommUtil();

		std::string GetCommName();


	private:
		struct CommUtilPrivate;
		CommUtilPrivate *_p;

	};

}
#endif // SatelliteRectPyramidEffectEffect_h__