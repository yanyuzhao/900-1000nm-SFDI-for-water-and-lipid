#include "CommUtil.h"
namespace ALP
{
	struct CommUtil::CommUtilPrivate
	{
		CommUtilPrivate()
			:name("Common Name")
		{
	
		}
		std::string name ;
	};

	CommUtil::CommUtil()
		:_p(new CommUtilPrivate())
	{

	}

	CommUtil::~CommUtil()
	{

	}

	std::string CommUtil::GetCommName()
	{
		return _p->name;
	}

}