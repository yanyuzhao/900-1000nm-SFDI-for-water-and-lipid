#ifndef XMLCOMMON_GLOBAL_H
#define XMLCOMMON_GLOBAL_H

#include <QtCore/qglobal.h>

#ifdef XMLCOMMON_LIB
# define XMLCOMMON_EXPORT Q_DECL_EXPORT
#else
# define XMLCOMMON_EXPORT Q_DECL_IMPORT
#endif

#endif // XMLCOMMON_GLOBAL_H
