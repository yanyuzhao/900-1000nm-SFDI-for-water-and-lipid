#include "XmlOperate.h"
#include <sstream>
#include <fstream>
#include "tinyxml.h"
#include <osgDB/ConvertUTF>

namespace XmlComm
{

	XmlNode::XmlNode(const std::string& name,bool isTextNode)
		:_name(name),_isTextNode(isTextNode)
	{
		
	}

	XmlNode::XmlNode(const std::string& name, const XmlAttributes& attrs,bool isTextNode)
		:_name(name),_isTextNode(isTextNode)
	{
		_propertys = attrs;
	}

	XmlNode::~XmlNode()
	{

	}

	void XmlNode::AddChild(osg::ref_ptr<XmlNode> child)
	{
		if ( _isTextNode )// 
		{
			return;
		}

		_children.push_back(child);
	}

	void XmlNode::SetIsTextNode(bool flag)
	{

	}

	bool XmlNode::IsTextNode()
	{
		return _isTextNode;
	}

	const std::string& XmlNode::GetName()
	{
		return _name;
	}

	void XmlNode::DelChildren(const std::string& name)
	{
		XmlNodeList::iterator itr = _children.begin();
		while(itr != _children.end() )
		{
			if ( osgEarth::toLower(name) == (*itr)->GetName() )
			{
				itr = _children.erase(itr);
				continue;
			}
			++itr;
		}
	}

	void XmlNode::DelChildren(const std::string& name,const std::vector<std::string>& porpertyNames,const std::vector<std::string>& porpertyValues)
	{
		if ( porpertyNames.size() != porpertyValues.size())
		{
			return;
		}
		XmlNodeList::iterator itr = _children.begin();
		while(itr != _children.end() )
		{
			if ( osgEarth::toLower(name) == (*itr)->GetName() )
			{
				bool flag = true;
				for ( unsigned i = 0; i<porpertyNames.size(); ++i)
				{
					std::string value;
					if ((*itr)->GetValue(porpertyNames.at(i),value) )
					{
						if ( value != porpertyValues.at(i))
						{
							flag = false;
						}
					}	
				}
				if ( flag )
				{
					itr = _children.erase(itr);
					continue;
				}
			}
			++itr;
		}
	}

	bool XmlNode::GetValue(const std::string& propertyName,std::string& propertyValue)
	{
		if ( _propertys.find(propertyName) == _propertys.end() )
		{
			return false;
		}
		propertyValue = _propertys[propertyName] ;

		return true;
	}

	void XmlNode::SetValue(const std::string& propertyName,const std::string& propertyValue)
	{
		_propertys[propertyName] = propertyValue ;
	}

	std::string XmlNode::GetText()
	{
		return _text;
	}

	void XmlNode::SetName(std::string name)
	{
		_name = name;
	}

	const XmlAttributes& XmlNode::getAttrs() const
	{
		return _propertys;
	}

	const XmlComm::XmlNodeList& XmlNode::GetChildren()
	{
		return _children;
	}

	std::vector<osg::ref_ptr<XmlNode>> XmlNode::FindChild(const std::string& name ,const std::string& propertyName ,const std::string& propertyValue)
	{
		std::vector<osg::ref_ptr<XmlNode>> tmpNodeList;
		XmlNodeList::iterator itr = _children.begin();
		while(itr != _children.end() )
		{
			if ( osgEarth::toLower(name) == (*itr)->GetName() )
			{
				std::string value;
				if ((*itr)->GetValue(propertyName,value) )
				{
					if ( value == propertyValue)
					{
						tmpNodeList.push_back((*itr));
					}
				}	
			}
			++itr;
		}
		return tmpNodeList;
	}

	std::vector<osg::ref_ptr<XmlNode>> XmlNode::FindChild(const std::string& name)
	{
		std::vector<osg::ref_ptr<XmlNode>> tmpNodeList;
		XmlNodeList::iterator itr = _children.begin();
		while(itr != _children.end() )
		{
			if ( osgEarth::toLower(name) == (*itr)->GetName() )
			{
				tmpNodeList.push_back((*itr));
			}
			++itr;
		}
		return tmpNodeList;
	}


	void OEXmlElement2LocaleXmlNode(osg::ref_ptr<osgEarth::XmlNode> xmlnode , osg::ref_ptr<XmlComm::XmlNode> localXmlNodeParent )
	{
		if ( xmlnode != NULL && localXmlNodeParent != NULL )
		{
			if ( xmlnode->isText())
			{
				return;
			}
			osgEarth::XmlElement* element = dynamic_cast<osgEarth::XmlElement*>(xmlnode.get());
			if ( element )
			{
				const osgEarth::XmlNodeList& nodeList = element->getChildren();
				osgEarth::XmlNodeList::const_iterator cItr = nodeList.begin();
				while(cItr != nodeList.end())
				{
					if ( (*cItr)->isText())
					{
						osgEarth::XmlText* child = dynamic_cast<osgEarth::XmlText*>((*cItr).get());
						if ( child != NULL )
						{
							osg::ref_ptr<XmlComm::XmlNode> newNode = new XmlComm::XmlNode(child->getValue(),true);
							localXmlNodeParent->AddChild(newNode);
						}
					}else
					{
						osgEarth::XmlElement* child = dynamic_cast<osgEarth::XmlElement*>((*cItr).get());
						if ( child != NULL )
						{
							osg::ref_ptr<XmlComm::XmlNode> newNode = new XmlComm::XmlNode(child->getName(),child->getAttrs());
							localXmlNodeParent->AddChild(newNode);
							OEXmlElement2LocaleXmlNode(child,newNode);
						}
					}
					
					
					++cItr;
				}
			}
		}
	}
	void LocaleXmlNodet2OEXmlElemen(osg::ref_ptr<osgEarth::XmlNode> xmlnode , osg::ref_ptr<XmlComm::XmlNode> localXmlNodeParent )
	{
		if ( xmlnode != NULL && localXmlNodeParent != NULL )
		{
			const XmlComm::XmlNodeList& nodeList = localXmlNodeParent->GetChildren();
			XmlComm::XmlNodeList::const_iterator cItr = nodeList.begin();
			while(cItr != nodeList.end())
			{
				if ( (*cItr)->IsTextNode())
				{
					osgEarth::XmlText* child = new osgEarth::XmlText((*cItr)->GetName());
					osgEarth::XmlElement* element = dynamic_cast<osgEarth::XmlElement*>(xmlnode.get());
					if (element)
					{
						element->getChildren().push_back(child);
					}
				}else
				{
					osgEarth::XmlElement* child = new osgEarth::XmlElement((*cItr)->GetName(),(*cItr)->getAttrs());
					osgEarth::XmlElement* element = dynamic_cast<osgEarth::XmlElement*>(xmlnode.get());
					if (element)
					{
						element->getChildren().push_back(child);
					}
					LocaleXmlNodet2OEXmlElemen(child,(*cItr));
				}
				++cItr;
			}

		}
	}
	osg::ref_ptr<XmlNode> XmlTool::LoadFile(const std::string& filePath)
	{
		osg::ref_ptr<XmlNode> xmlNode = NULL;
		osg::ref_ptr<osgEarth::XmlDocument> doc = osgEarth::XmlDocument::load(filePath);
		if (doc!=NULL)
		{
			xmlNode = new XmlNode("",doc->getAttrs());
			OEXmlElement2LocaleXmlNode(doc,xmlNode);
		}
		return xmlNode;
	}

	bool XmlTool::SaveFile(const std::string& filePath,const osg::ref_ptr<XmlNode> xmlNode)
	{
		if ( xmlNode == NULL )
		{
			return false;
		}
		if ( ! xmlNode->GetChildren().size() )
		{
			return false;
		}
		std::ofstream out( filePath.c_str());
		if ( !out.is_open() )
		{
			return false;
		}
		
		osg::ref_ptr<osgEarth::XmlDocument> doc = new osgEarth::XmlDocument( xmlNode->GetChildren().at(0)->GetName());
		doc->getAttrs() = xmlNode->GetChildren().at(0)->getAttrs();
		LocaleXmlNodet2OEXmlElemen(doc,xmlNode->GetChildren().at(0));
		doc->store(out);
		return true;
	}
	static void
		storeNode( const osgEarth::XmlNode* node, TiXmlNode* parent)
	{
		if (node->isElement())
		{
			osgEarth::XmlElement* e = (osgEarth::XmlElement*)node;
			TiXmlElement* element = new TiXmlElement( e->getName().c_str() );
			//Write out all the attributes
			for( XmlAttributes::iterator a = e->getAttrs().begin(); a != e->getAttrs().end(); a++ )
			{
				element->SetAttribute(a->first.c_str(), a->second.c_str() );            
			}

			//Write out all the child nodes
			for( osgEarth::XmlNodeList::iterator i = e->getChildren().begin(); i != e->getChildren().end(); i++ )
			{
				storeNode( i->get(), element );
			}
			parent->LinkEndChild( element );
		}
		else if (node->isText())
		{
			osgEarth::XmlText* t = (osgEarth::XmlText*)node;
			parent->LinkEndChild( new TiXmlText( t->getValue().c_str() ) );
		}
	}
	bool XmlTool::SaveFile(const std::string& filePath,const osg::ref_ptr<XmlNode> xmlNode, const char* _encoding, const char* _standalone, const char* _version)
	{
		if ( xmlNode == NULL )
		{
			return false;
		}
		if ( ! xmlNode->GetChildren().size() )
		{
			return false;
		}
		std::ofstream out( filePath.c_str());
		if ( !out.is_open() )
		{
			return false;
		}

		osg::ref_ptr<osgEarth::XmlDocument> doc = new osgEarth::XmlDocument( xmlNode->GetChildren().at(0)->GetName());
		doc->getAttrs() = xmlNode->GetChildren().at(0)->getAttrs();
		LocaleXmlNodet2OEXmlElemen(doc,xmlNode->GetChildren().at(0));
		

		TiXmlDocument docTiXml;
		docTiXml.LinkEndChild( new TiXmlDeclaration( _version,_encoding, _standalone));
		storeNode( doc, &docTiXml );    


		//Use TiXmlPrinter to do pretty printing.
		TiXmlPrinter printer;
		printer.SetIndent("  ");
		docTiXml.Accept(&printer);
		
		out << printer.CStr();

		return true;
	}

}