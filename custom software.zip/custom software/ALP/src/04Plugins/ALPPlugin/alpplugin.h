#ifndef ALPPLUGIN_H
#define ALPPLUGIN_H
#include "ALPEasyPrcWidget.h"
#include <AppliactionFrame/PluginManager.h>
#include <AppliactionFrame/ApplicationFrame.h>
#include <QObject>
#include <QtGui/QMainWindow>
#include <QtCore/QTime>
#include <QtGui\QToolBar>
#include <QStatusBar>
#include <QMenuBar>
#include "alpplugin_global.h"



class ALPPLUGIN_EXPORT ALPPlugin:public QObject,public Frame::Plugin
{
	Q_OBJECT
public:
	ALPPlugin();
	~ALPPlugin();

	//��������ص�
	void Create(Frame::ApplicationFrame* appFrame) ;
	//���ٲ���ص�
	void Destroy();
private slots:
	void OnAlpMenuSelect();

private:
	void InitStatuesSet();//��ʼ��״̬����

	QMenu* GetOrAddMenu(QString menuName,QMainWindow* mw);

private:
	Frame::ApplicationFrame* _appFrame;// �����

	QStatusBar *_statusbar;//״̬��
	ALPEasyPrcWidget* _ALPEasyPrcWidget;
};

#endif // ALPPLUGIN_H
