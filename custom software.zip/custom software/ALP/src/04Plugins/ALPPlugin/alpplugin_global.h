#ifndef ALPPLUGIN_GLOBAL_H
#define ALPPLUGIN_GLOBAL_H

#include <QtCore/qglobal.h>

#ifdef ALPPLUGIN_LIB
# define ALPPLUGIN_EXPORT Q_DECL_EXPORT
#else
# define ALPPLUGIN_EXPORT Q_DECL_IMPORT
#endif

#endif // ALPPLUGIN_GLOBAL_H
