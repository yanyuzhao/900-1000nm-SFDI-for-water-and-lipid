#include "alpplugin.h"

ALPPlugin::ALPPlugin()
{

}

ALPPlugin::~ALPPlugin()
{

}

void ALPPlugin::Create(Frame::ApplicationFrame* appFrame)
{
	if(!appFrame)
		return;
	_appFrame=appFrame;
	QMainWindow *manwindow=(QMainWindow*)(appFrame->GetMainWindow());
	if(!manwindow)
		return;
	if(!_appFrame)
		return ;
	_statusbar=manwindow->statusBar();
	InitStatuesSet();

	if ( manwindow )
		{
			QMenu* menu = GetOrAddMenu("ALP",manwindow);
			if ( menu )
			{
				QAction* alpAction = new QAction("AlpSetting",this);
				menu->addAction(alpAction);	
				bool flag = connect(alpAction,SIGNAL(triggered()),this,SLOT(OnAlpMenuSelect()));
				int a = 0;
			}
			_ALPEasyPrcWidget = new ALPEasyPrcWidget(nullptr);
		}
}

void ALPPlugin::Destroy()
{

}

void ALPPlugin::OnAlpMenuSelect()
{
	QString text = "ALPMenuSelect";
	_ALPEasyPrcWidget->show();
	_statusbar->showMessage(text);
}

void ALPPlugin::InitStatuesSet()
{
	QString text = "����һ�����Գ���";
	_statusbar->showMessage(text);
}

QMenu* ALPPlugin::GetOrAddMenu(QString menuName,QMainWindow* mw)
{
	if ( mw )
	{
		QList<QAction*> actions = mw->menuBar()->actions();
		QList<QAction*>::iterator itrAction = actions.begin();

		while( itrAction != actions.end() )
		{
			QString text = (*itrAction)->text();
			if ( (*itrAction)->text() == menuName )
			{
				return (*itrAction)->menu();
			}
			++itrAction;
		}
		return mw->menuBar()->addMenu(menuName);
	}
	return NULL;
}
extern "C" ALPPLUGIN_EXPORT Frame::Plugin* CreatePlugin()
{
	return new ALPPlugin();
}