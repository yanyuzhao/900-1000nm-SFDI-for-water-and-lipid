#include "ALPEasyPrcWidget.h"
#include <QFileDialog>
#include <comdef.h>
#include <gdiplus.h>
ALPEasyPrcWidget::ALPEasyPrcWidget(QWidget* parent /*= NULL*/)

	:QWidget(parent)
{
	_ui = new Ui::ALPWidget();
	_ui->setupUi(this);
	InitConnect();
	_ui->ImageBtn->setIconSize(QSize(200,200));
	_Projector = new   CProjector();
	_ui->masterModeBtn->setEnabled(false);

}

ALPEasyPrcWidget::~ALPEasyPrcWidget()
{
	if (_Projector)
	{
		_Projector->SequenceFree();
		_Projector->Free();
	}
}

void ALPEasyPrcWidget::OnAllocBtnClicked()
{
	int ret = _Projector->Alloc();

	if( ALP_OK == ret)
		ret = GetProjectorProperties();


	SetProjectorReturnCodeMsg( ret);
	UpdateElements();	
}

void ALPEasyPrcWidget::OnFreeBtnClicked()
{
	_Projector->ProjStop();
	FreeSequence();

	int ret = FreeProjector();
	SetProjectorReturnCodeMsg( ret);
	UpdateElements();		

}

void ALPEasyPrcWidget::OnHighRadioClicked(bool value)
{
	m_iSyncPolarity = 0;
	long synchMode = ALP_LEVEL_HIGH;
	_Projector->SetSyncOutputMode(synchMode);
}

void ALPEasyPrcWidget::OnLowRadioClicked(bool value)
{
	m_iSyncPolarity = 1;
	long synchMode = ALP_LEVEL_LOW;
	_Projector->SetSyncOutputMode(synchMode);
}

void ALPEasyPrcWidget::OnBrightHorizontalSladerValueChanged()
{

}

void ALPEasyPrcWidget::OnLoadSequeBtnClicked()
{
	int ret = LoadSequence();
	GetSequenceProperties();
	SetProjectorReturnCodeMsg( ret);
	UpdateElements();	
}

void ALPEasyPrcWidget::OnFreeSequeBtnClicked()
{
	int ret = FreeSequence();
	SetProjectorReturnCodeMsg( ret);
	UpdateElements();		
}

void ALPEasyPrcWidget::OnProjectionBtnClicked()
{
	int ret = _Projector->ProjStartContinuous();
	SetProjectorReturnCodeMsg( ret);
	UpdateElements();	
}

void ALPEasyPrcWidget::OnStopSequeBtnClicked()
{
	int ret = _Projector->ProjStop();
	SetProjectorReturnCodeMsg( ret);
	UpdateElements();
}

void ALPEasyPrcWidget::OnSequeSettingBtnClicked()
{
	int ret = SetSequenceProperties();

	// In case of a running projection the changes gets effective even after Stop/Start of the projection.
	if( ALP_OK == ret
		&&	_Projector->IsProjection())
	{
		_Projector->ProjStop();
		_Projector->ProjStartContinuous();
	}

	// After successful timing setup, report effective settings. These values could
	// differ from input in case of inconsistent parameters or ALP_DEFAULT.
	// On failure the user interface parameters shall be adjustable individually, so they are not overwritten.
	if (ALP_OK==ret)
		GetSequenceProperties();
	SetProjectorReturnCodeMsg( ret);
	UpdateElements();	
}

void ALPEasyPrcWidget::OnQuitBtnClicked()
{

}

void ALPEasyPrcWidget::OnSlaveModeClicked()
{
	int ret = _Projector->SetSlaveMode();
	if (ALP_OK!=ret)
	{
		SetProjectorReturnCodeMsg( ret);
	}
	else
	{
		_ui->SlaveModeBtn->setEnabled(false);
		_ui->masterModeBtn->setEnabled(true);
	}


}
void ALPEasyPrcWidget::ONMaseterModeBtnClicked()
{
	int ret = _Projector->SetMaseterMode();
	if (ALP_OK!=ret)
	{
		SetProjectorReturnCodeMsg( ret);
	}
	else
	{
		_ui->SlaveModeBtn->setEnabled(true);
		_ui->masterModeBtn->setEnabled(false);
	}
}


void ALPEasyPrcWidget::InitConnect()
{
	//	bool flag = connect(alpAction,SIGNAL(triggered()),this,SLOT(OnAlpMenuSelect()));
	bool flag = connect(_ui->AllocBtn,SIGNAL(clicked()),this,SLOT(OnAllocBtnClicked()));
	flag = connect(_ui->FreeBtn,SIGNAL(clicked()),this,SLOT(OnFreeBtnClicked()));
	flag = connect(_ui->HighradioButton,SIGNAL(toggled(bool)),this,SLOT(OnHighRadioClicked(bool)));
	flag = connect(_ui->LowradioButton,SIGNAL(toggled(bool)),this,SLOT(OnLowRadioClicked(bool)));
	flag = connect(_ui->LoadBtn,SIGNAL(clicked()),this,SLOT(OnLoadSequeBtnClicked()));
	flag = connect(_ui->FreeSequeBtn,SIGNAL(clicked()),this,SLOT(OnFreeSequeBtnClicked()));
	flag = connect(_ui->ProjectionBtn,SIGNAL(clicked()),this,SLOT(OnProjectionBtnClicked()));
	flag = connect(_ui->StopBtn,SIGNAL(clicked()),this,SLOT(OnStopSequeBtnClicked()));
	flag = connect(_ui->SetBtn,SIGNAL(clicked()),this,SLOT(OnSequeSettingBtnClicked()));
	flag = connect(_ui->QuitBtn,SIGNAL(clicked()),this,SLOT(OnQuitBtnClicked()));
	flag = connect(_ui->SlaveModeBtn,SIGNAL(clicked()),this,SLOT(OnSlaveModeClicked()));
	flag = connect(_ui->masterModeBtn,SIGNAL(clicked()),this,SLOT(ONMaseterModeBtnClicked()));
	int a = 0;
}

void ALPEasyPrcWidget::SetProjectorReturnCodeMsg(const int retCode)
{
	wchar_t* errorMessaget = new wchar_t[512];
	_Projector->GetErrorMessage(retCode,errorMessaget,512);
	QString errorInfo = QString::fromWCharArray(errorMessaget);
	_ui->ProjectorLabel->setText("succees");
	_ui->ReturnCodeLabel->setText("succees");
	if( ALP_OK != retCode)
	{
		QString errorInfo = QString::fromWCharArray(errorMessaget);
		_ui->ReturnCodeLabel->setText(errorInfo);
		_ui->ProjectorLabel->setText(errorInfo);
	}
}

void ALPEasyPrcWidget::UpdateElements(void)
{
	bool bValidProjector = _Projector->IsConnected(),
		 bValidSeqence = bValidProjector && _Projector->IsValidSequence();

	_ui->AllocBtn->setEnabled( !bValidProjector);
	_ui->FreeBtn->setEnabled( bValidProjector);

	_ui->HighradioButton->setEnabled( bValidProjector);
	_ui->LowradioButton->setEnabled( bValidProjector);

	_ui->LoadBtn->setEnabled(bValidProjector && !bValidSeqence);
	_ui->FreeSequeBtn->setEnabled(bValidSeqence);
	_ui->IlluminateTmlineEdit->setEnabled(bValidSeqence);
	_ui->PictureTmlineEdit->setEnabled(bValidSeqence);

	_ui->SyncDelaylineEdit->setEnabled(bValidSeqence);
	_ui->SynchPulseWidthlineEdit->setEnabled(bValidSeqence);
	_ui->ProjectionBtn->setEnabled(bValidSeqence);
	_ui->StopBtn->setEnabled(bValidSeqence);
	_ui->SetBtn->setEnabled(bValidSeqence);
}

const int ALPEasyPrcWidget::FreeProjector(void)
{
	int ret = _Projector->Free();
	_ui->SerialNumberLabel->setText("");
	return ret;
}

const int ALPEasyPrcWidget::GetProjectorProperties(void)
{
	CProjector::CDevProperties prop;
	int ret = _Projector->GetDevProperties( prop);
	if( ALP_OK == ret)
	{
		_ui->SerialNumberLabel->setText(QString::number(prop.SerialNumber));
		
		switch( prop.Polarity)
		{
		case ALP_LEVEL_HIGH:	m_iSyncPolarity = 0; break;
		case ALP_LEVEL_LOW:		m_iSyncPolarity = 1; break;
		default: m_iSyncPolarity = 0; break;
		}
	}

	return ret;
}

const int ALPEasyPrcWidget::SetSyncPolarity()
{
	long synchMode;												// update direction: dialog elements -> data
	switch( m_iSyncPolarity)
	{
	case 0: synchMode = ALP_LEVEL_HIGH; break;
	case 1: synchMode = ALP_LEVEL_LOW; break;
	default: synchMode = ALP_LEVEL_HIGH; break; 
	}
	return _Projector->SetSyncOutputMode( synchMode);
}

const int ALPEasyPrcWidget::FreeSequence(void)
{
	int ret = ALP_OK;
	if( _Projector->IsValidSequence())
	{
		ret = _Projector->SequenceFree();
	}
	_ui->Loadlabel->setText("");
	_ui->IlluminateTmlineEdit->setText("");
	_ui->PictureTmlineEdit->setText("");
	_ui->SyncDelaylineEdit->setText("");
	_ui->SynchPulseWidthlineEdit->setText("");
	_ui->NumberofBitlanesslineEdit->setText("");
	QIcon icon;
	_ui->ImageBtn->setIcon(icon);
	return ret;
}

const int ALPEasyPrcWidget::GetSequenceProperties(void)
{
	CProjector::CTimingEx timing;
	int ret = _Projector->GetSeqProperties( timing);
	if( ALP_OK == ret)
	{
		_ui->IlluminateTmlineEdit->setText(QString::number(timing.IlluminateTime));
		_ui->PictureTmlineEdit->setText(QString::number(timing.PictureTime));
		_ui->SynchPulseWidthlineEdit->setText(QString::number(timing.SynchPulseWidth));
		_ui->SyncDelaylineEdit->setText(QString::number(timing.SynchDelay));
		_ui->NumberofBitlanesslineEdit->setText(QString::number(timing.BitNum));
;
		if (timing.Uninterrupted) _ui->NumberofBitlanesslineEdit->setText(" uninterrupted");
	}
	return ret;
}

const int ALPEasyPrcWidget::SetSequenceProperties(void)
{
	CProjector::CTimingEx timing;
	timing.IlluminateTime = _ui->IlluminateTmlineEdit->text().toLong(); 

	timing.PictureTime = _ui->PictureTmlineEdit->text().toLong();

	timing.SynchDelay = _ui->SyncDelaylineEdit->text().toLong();

	timing.SynchPulseWidth =  _ui->SynchPulseWidthlineEdit->text().toLong();


	return  _Projector->SelectMaxBitnum( timing );

}

const int ALPEasyPrcWidget::LoadSequence(void)
{
	int ret = ALP_OK;
	int nImages = 0;
	QStringList fileList = QFileDialog::getOpenFileNames(
		this, ("select picture"), tr("png"), tr("Images (*.png *.tif *.jpg)"));
	if(fileList.size() > 0)											// show file open dialog
	{

		nImages = fileList.size();

		const int BitPlanes = _ui->BitPlaneCbx->currentText().toInt();									// use all bitplanes for projection
		ret = _Projector->SequenceAlloc( BitPlanes, nImages);		// create a sequence
		if( ALP_OK != ret)
		{
			SetProjectorReturnCodeMsg(ret);
			return ret; 
		}


		// read images from file, convert it and put it to the projector
		Gdiplus::Status status;
		int k = 0;	
		for(int i = 0; i < fileList.size(); i++ )
		{
			//CString fileNameLOAD = dlg.GetNextPathName(pos);
			QString path = fileList.at(i);
			wchar_t szBuf[1024];
			wcscpy_s(reinterpret_cast<wchar_t*>(szBuf),
				sizeof(szBuf) / sizeof(wchar_t),
				reinterpret_cast<const wchar_t*>(path.utf16()));
			Gdiplus::Bitmap BmpLoaded(szBuf);			// read the image from file

			// create a new bitmap with projector dimensions
			std::auto_ptr<Gdiplus::Bitmap> pProjBmp(new Gdiplus::Bitmap( _Projector->GetWidth(), _Projector->GetHeight(), PixelFormat24bppRGB));
			Gdiplus::Graphics projGraphics( pProjBmp.get() );

			// create a 8bpp-sequence-image as bitmap with projector dimensions
			std::auto_ptr<Gdiplus::Bitmap> pSeqImageBmp(new Gdiplus::Bitmap( _Projector->GetWidth(), _Projector->GetHeight(), PixelFormat8bppIndexed));

			// create a bitmap for the preview with preview dimensions
			const int thumbWidth = 176;
			const int thumbHeight = 132;
			std::auto_ptr<Gdiplus::Bitmap> pThumbBmp(new Gdiplus::Bitmap( thumbWidth, thumbHeight, PixelFormat24bppRGB));
			Gdiplus::Graphics thumbGraphics(pThumbBmp.get());	// connect the drawing area with preview


			if( BmpLoaded.GetWidth() == pProjBmp->GetWidth()
				&&	BmpLoaded.GetHeight() == pProjBmp->GetHeight())
			{
				// resize not necessary -> clone the bitmap
				pProjBmp.reset(BmpLoaded.Clone( 0, 0, _Projector->GetWidth(), _Projector->GetHeight(), PixelFormat24bppRGB));
			}
			else
			{
				// draw bitmap into the drawing area of the sequence image, resize
				status = projGraphics.DrawImage( &BmpLoaded, 0, 0, _Projector->GetWidth(), _Projector->GetHeight());
			}

			if( pProjBmp->GetWidth() != pSeqImageBmp->GetWidth()
				||	pProjBmp->GetHeight() != pSeqImageBmp->GetHeight())
				break;

			// lock RGB image for read access
			Gdiplus::Rect lockRect( 0, 0, pProjBmp->GetWidth(), pProjBmp->GetHeight());	
			Gdiplus::BitmapData bitmapDataProj;		// image data
			pProjBmp->LockBits( &lockRect, Gdiplus::ImageLockModeWrite, PixelFormat24bppRGB, &bitmapDataProj);

			// lock 8bpp sequence image for write access
			Gdiplus::BitmapData bitmapData8bpp;		// image data
			pSeqImageBmp->LockBits( &lockRect, Gdiplus::ImageLockModeWrite, PixelFormat8bppIndexed, &bitmapData8bpp);

			BYTE *pImageDataProj = static_cast<BYTE*>(bitmapDataProj.Scan0);	// pointer to the first pixel of the first line (RGB image: source)
			BYTE *pImageData8bpp = static_cast<BYTE*>(bitmapData8bpp.Scan0);	// pointer to the first pixel of the first line (8bpp image: target)

			// transform pixel wise: RGB -> 8bpp
			for( size_t y=0; y < pProjBmp->GetHeight(); y++)
			{
				for( size_t x=0; x < pProjBmp->GetWidth(); x++)
				{
					pImageData8bpp[x] =	( pImageDataProj[ x*3]		// B
					+ pImageDataProj[ x*3+1]	// G
					+ pImageDataProj[ x*3+2]	// R
					) / 3;
				}
				pImageDataProj += bitmapDataProj.Stride;				// set pointer to the first pixel of the next line
				pImageData8bpp += bitmapData8bpp.Stride;				// set pointer to the first pixel of the next line
			}

			pImageData8bpp = static_cast<BYTE*>(bitmapData8bpp.Scan0);	// set pointer back to the first pixel of the first line (RGB image: source)
			ret = _Projector->AddImage( pImageData8bpp, pSeqImageBmp->GetWidth(), pSeqImageBmp->GetHeight());		// upload image to the projector an add to sequence

			status = pProjBmp->UnlockBits(&bitmapDataProj);	// lock end
			status = pSeqImageBmp->UnlockBits(&bitmapData8bpp);	// lock end

			if( ALP_OK != ret)
				break;
			_ui->Loadlabel->setText(QString::number(i+1));
			QIcon icon(fileList.at(i));
			_ui->ImageBtn->setIcon(icon);
			// update dialog element with current image counter

			// draw BmpLoaded in the drawing area of the preview
			status = thumbGraphics.DrawImage( &BmpLoaded, 0, 0, thumbWidth, thumbHeight);	
			HBITMAP hBmp = 0;
			status = pThumbBmp->GetHBITMAP( Gdiplus::Color(0,0,0), &hBmp);	// get bitmap handle

			DeleteObject(hBmp);

			k++;
		}
	}
	return ret;
}


