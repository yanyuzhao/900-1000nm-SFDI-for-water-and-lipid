/********************************************************************************
** Form generated from reading UI file 'ALPEasyPrcWidget.ui'
**
** Created: Sun Jun 28 07:20:33 2020
**      by: Qt User Interface Compiler version 4.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ALPEASYPRCWIDGET_H
#define UI_ALPEASYPRCWIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QGridLayout>
#include <QtGui/QGroupBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QRadioButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QToolButton>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ALPWidget
{
public:
    QGroupBox *groupBox;
    QWidget *widget;
    QGridLayout *gridLayout_3;
    QPushButton *AllocBtn;
    QLabel *label;
    QPushButton *FreeBtn;
    QLabel *SerialNumberLabel;
    QGroupBox *groupBox_2;
    QLabel *label_3;
    QRadioButton *HighradioButton;
    QRadioButton *LowradioButton;
    QLabel *label_7;
    QLabel *ReturnCodeLabel;
    QGroupBox *groupBox_5;
    QLabel *Loadlabel;
    QToolButton *ImageBtn;
    QWidget *widget1;
    QGridLayout *gridLayout_2;
    QPushButton *LoadBtn;
    QPushButton *FreeSequeBtn;
    QLabel *label_2;
    QComboBox *BitPlaneCbx;
    QPushButton *ProjectionBtn;
    QPushButton *StopBtn;
    QGroupBox *groupBox_6;
    QPushButton *SetBtn;
    QWidget *layoutWidget;
    QGridLayout *gridLayout;
    QLabel *label_10;
    QLineEdit *IlluminateTmlineEdit;
    QLabel *label_11;
    QLineEdit *PictureTmlineEdit;
    QLabel *label_12;
    QLineEdit *SyncDelaylineEdit;
    QLabel *label_13;
    QLineEdit *SynchPulseWidthlineEdit;
    QLabel *label_14;
    QLineEdit *NumberofBitlanesslineEdit;
    QGroupBox *groupBox_7;
    QLabel *ProjectorLabel;
    QPushButton *QuitBtn;
    QWidget *widget2;
    QHBoxLayout *horizontalLayout;
    QToolButton *SlaveModeBtn;
    QPushButton *masterModeBtn;
    QSpacerItem *horizontalSpacer;

    void setupUi(QWidget *ALPWidget)
    {
        if (ALPWidget->objectName().isEmpty())
            ALPWidget->setObjectName(QString::fromUtf8("ALPWidget"));
        ALPWidget->resize(561, 574);
        groupBox = new QGroupBox(ALPWidget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(10, 20, 191, 111));
        widget = new QWidget(groupBox);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(10, 30, 171, 54));
        gridLayout_3 = new QGridLayout(widget);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        gridLayout_3->setContentsMargins(0, 0, 0, 0);
        AllocBtn = new QPushButton(widget);
        AllocBtn->setObjectName(QString::fromUtf8("AllocBtn"));

        gridLayout_3->addWidget(AllocBtn, 0, 0, 1, 1);

        label = new QLabel(widget);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout_3->addWidget(label, 0, 1, 1, 1);

        FreeBtn = new QPushButton(widget);
        FreeBtn->setObjectName(QString::fromUtf8("FreeBtn"));

        gridLayout_3->addWidget(FreeBtn, 1, 0, 1, 1);

        SerialNumberLabel = new QLabel(widget);
        SerialNumberLabel->setObjectName(QString::fromUtf8("SerialNumberLabel"));

        gridLayout_3->addWidget(SerialNumberLabel, 1, 1, 1, 1);

        groupBox_2 = new QGroupBox(ALPWidget);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setGeometry(QRect(10, 140, 191, 61));
        label_3 = new QLabel(groupBox_2);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(10, 30, 54, 12));
        HighradioButton = new QRadioButton(groupBox_2);
        HighradioButton->setObjectName(QString::fromUtf8("HighradioButton"));
        HighradioButton->setGeometry(QRect(70, 30, 61, 17));
        HighradioButton->setChecked(true);
        LowradioButton = new QRadioButton(groupBox_2);
        LowradioButton->setObjectName(QString::fromUtf8("LowradioButton"));
        LowradioButton->setGeometry(QRect(130, 30, 51, 17));
        label_7 = new QLabel(ALPWidget);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(20, 460, 81, 16));
        ReturnCodeLabel = new QLabel(ALPWidget);
        ReturnCodeLabel->setObjectName(QString::fromUtf8("ReturnCodeLabel"));
        ReturnCodeLabel->setGeometry(QRect(20, 490, 71, 16));
        groupBox_5 = new QGroupBox(ALPWidget);
        groupBox_5->setObjectName(QString::fromUtf8("groupBox_5"));
        groupBox_5->setGeometry(QRect(210, 20, 351, 181));
        Loadlabel = new QLabel(groupBox_5);
        Loadlabel->setObjectName(QString::fromUtf8("Loadlabel"));
        Loadlabel->setGeometry(QRect(190, 0, 111, 31));
        ImageBtn = new QToolButton(groupBox_5);
        ImageBtn->setObjectName(QString::fromUtf8("ImageBtn"));
        ImageBtn->setGeometry(QRect(180, 40, 111, 131));
        widget1 = new QWidget(groupBox_5);
        widget1->setObjectName(QString::fromUtf8("widget1"));
        widget1->setGeometry(QRect(20, 30, 131, 141));
        gridLayout_2 = new QGridLayout(widget1);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        LoadBtn = new QPushButton(widget1);
        LoadBtn->setObjectName(QString::fromUtf8("LoadBtn"));

        gridLayout_2->addWidget(LoadBtn, 0, 0, 1, 1);

        FreeSequeBtn = new QPushButton(widget1);
        FreeSequeBtn->setObjectName(QString::fromUtf8("FreeSequeBtn"));

        gridLayout_2->addWidget(FreeSequeBtn, 0, 1, 1, 1);

        label_2 = new QLabel(widget1);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout_2->addWidget(label_2, 1, 0, 1, 1);

        BitPlaneCbx = new QComboBox(widget1);
        BitPlaneCbx->setObjectName(QString::fromUtf8("BitPlaneCbx"));

        gridLayout_2->addWidget(BitPlaneCbx, 1, 1, 1, 1);

        ProjectionBtn = new QPushButton(widget1);
        ProjectionBtn->setObjectName(QString::fromUtf8("ProjectionBtn"));

        gridLayout_2->addWidget(ProjectionBtn, 2, 0, 1, 2);

        StopBtn = new QPushButton(widget1);
        StopBtn->setObjectName(QString::fromUtf8("StopBtn"));

        gridLayout_2->addWidget(StopBtn, 3, 0, 1, 2);

        groupBox_6 = new QGroupBox(ALPWidget);
        groupBox_6->setObjectName(QString::fromUtf8("groupBox_6"));
        groupBox_6->setGeometry(QRect(10, 200, 501, 241));
        SetBtn = new QPushButton(groupBox_6);
        SetBtn->setObjectName(QString::fromUtf8("SetBtn"));
        SetBtn->setGeometry(QRect(50, 200, 161, 23));
        layoutWidget = new QWidget(groupBox_6);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(20, 30, 421, 161));
        gridLayout = new QGridLayout(layoutWidget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        label_10 = new QLabel(layoutWidget);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        gridLayout->addWidget(label_10, 0, 0, 1, 1);

        IlluminateTmlineEdit = new QLineEdit(layoutWidget);
        IlluminateTmlineEdit->setObjectName(QString::fromUtf8("IlluminateTmlineEdit"));

        gridLayout->addWidget(IlluminateTmlineEdit, 0, 1, 1, 1);

        label_11 = new QLabel(layoutWidget);
        label_11->setObjectName(QString::fromUtf8("label_11"));

        gridLayout->addWidget(label_11, 1, 0, 1, 1);

        PictureTmlineEdit = new QLineEdit(layoutWidget);
        PictureTmlineEdit->setObjectName(QString::fromUtf8("PictureTmlineEdit"));

        gridLayout->addWidget(PictureTmlineEdit, 1, 1, 1, 1);

        label_12 = new QLabel(layoutWidget);
        label_12->setObjectName(QString::fromUtf8("label_12"));

        gridLayout->addWidget(label_12, 2, 0, 1, 1);

        SyncDelaylineEdit = new QLineEdit(layoutWidget);
        SyncDelaylineEdit->setObjectName(QString::fromUtf8("SyncDelaylineEdit"));

        gridLayout->addWidget(SyncDelaylineEdit, 2, 1, 1, 1);

        label_13 = new QLabel(layoutWidget);
        label_13->setObjectName(QString::fromUtf8("label_13"));

        gridLayout->addWidget(label_13, 3, 0, 1, 1);

        SynchPulseWidthlineEdit = new QLineEdit(layoutWidget);
        SynchPulseWidthlineEdit->setObjectName(QString::fromUtf8("SynchPulseWidthlineEdit"));

        gridLayout->addWidget(SynchPulseWidthlineEdit, 3, 1, 1, 1);

        label_14 = new QLabel(layoutWidget);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        QFont font;
        font.setPointSize(9);
        label_14->setFont(font);

        gridLayout->addWidget(label_14, 4, 0, 1, 1);

        NumberofBitlanesslineEdit = new QLineEdit(layoutWidget);
        NumberofBitlanesslineEdit->setObjectName(QString::fromUtf8("NumberofBitlanesslineEdit"));

        gridLayout->addWidget(NumberofBitlanesslineEdit, 4, 1, 1, 1);

        groupBox_7 = new QGroupBox(ALPWidget);
        groupBox_7->setObjectName(QString::fromUtf8("groupBox_7"));
        groupBox_7->setGeometry(QRect(110, 460, 331, 51));
        ProjectorLabel = new QLabel(groupBox_7);
        ProjectorLabel->setObjectName(QString::fromUtf8("ProjectorLabel"));
        ProjectorLabel->setGeometry(QRect(10, 20, 301, 16));
        QuitBtn = new QPushButton(ALPWidget);
        QuitBtn->setObjectName(QString::fromUtf8("QuitBtn"));
        QuitBtn->setGeometry(QRect(450, 460, 41, 51));
        widget2 = new QWidget(ALPWidget);
        widget2->setObjectName(QString::fromUtf8("widget2"));
        widget2->setGeometry(QRect(20, 520, 521, 25));
        horizontalLayout = new QHBoxLayout(widget2);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        SlaveModeBtn = new QToolButton(widget2);
        SlaveModeBtn->setObjectName(QString::fromUtf8("SlaveModeBtn"));

        horizontalLayout->addWidget(SlaveModeBtn);

        masterModeBtn = new QPushButton(widget2);
        masterModeBtn->setObjectName(QString::fromUtf8("masterModeBtn"));

        horizontalLayout->addWidget(masterModeBtn);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);


        retranslateUi(ALPWidget);

        QMetaObject::connectSlotsByName(ALPWidget);
    } // setupUi

    void retranslateUi(QWidget *ALPWidget)
    {
        ALPWidget->setWindowTitle(QApplication::translate("ALPWidget", "Form", 0, QApplication::UnicodeUTF8));
        groupBox->setTitle(QApplication::translate("ALPWidget", "Projector Device", 0, QApplication::UnicodeUTF8));
        AllocBtn->setText(QApplication::translate("ALPWidget", "Alloc", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("ALPWidget", "Serial Number", 0, QApplication::UnicodeUTF8));
        FreeBtn->setText(QApplication::translate("ALPWidget", "Free", 0, QApplication::UnicodeUTF8));
        SerialNumberLabel->setText(QApplication::translate("ALPWidget", "TextLabel", 0, QApplication::UnicodeUTF8));
        groupBox_2->setTitle(QApplication::translate("ALPWidget", "Projector Settings", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("ALPWidget", "Sync Polerity", 0, QApplication::UnicodeUTF8));
        HighradioButton->setText(QApplication::translate("ALPWidget", "High", 0, QApplication::UnicodeUTF8));
        LowradioButton->setText(QApplication::translate("ALPWidget", "Low", 0, QApplication::UnicodeUTF8));
        label_7->setText(QApplication::translate("ALPWidget", "Return Code", 0, QApplication::UnicodeUTF8));
        ReturnCodeLabel->setText(QApplication::translate("ALPWidget", "TextLabel", 0, QApplication::UnicodeUTF8));
        groupBox_5->setTitle(QApplication::translate("ALPWidget", "Sequence", 0, QApplication::UnicodeUTF8));
        Loadlabel->setText(QApplication::translate("ALPWidget", "Picture Number", 0, QApplication::UnicodeUTF8));
        ImageBtn->setText(QApplication::translate("ALPWidget", "...", 0, QApplication::UnicodeUTF8));
        LoadBtn->setText(QApplication::translate("ALPWidget", "load", 0, QApplication::UnicodeUTF8));
        FreeSequeBtn->setText(QApplication::translate("ALPWidget", "Free", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("ALPWidget", "PlaneBit", 0, QApplication::UnicodeUTF8));
        BitPlaneCbx->clear();
        BitPlaneCbx->insertItems(0, QStringList()
         << QApplication::translate("ALPWidget", "1", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ALPWidget", "2", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ALPWidget", "3", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ALPWidget", "4", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ALPWidget", "5", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ALPWidget", "6", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ALPWidget", "7", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ALPWidget", "8", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ALPWidget", "9", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ALPWidget", "10", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ALPWidget", "11", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ALPWidget", "12", 0, QApplication::UnicodeUTF8)
        );
        ProjectionBtn->setText(QApplication::translate("ALPWidget", "Projection", 0, QApplication::UnicodeUTF8));
        StopBtn->setText(QApplication::translate("ALPWidget", "Stop", 0, QApplication::UnicodeUTF8));
        groupBox_6->setTitle(QApplication::translate("ALPWidget", "Sequence Timing", 0, QApplication::UnicodeUTF8));
        SetBtn->setText(QApplication::translate("ALPWidget", "Set", 0, QApplication::UnicodeUTF8));
        label_10->setText(QApplication::translate("ALPWidget", "Illuminate Time", 0, QApplication::UnicodeUTF8));
        label_11->setText(QApplication::translate("ALPWidget", "Picture Time", 0, QApplication::UnicodeUTF8));
        label_12->setText(QApplication::translate("ALPWidget", "Synch Delay", 0, QApplication::UnicodeUTF8));
        label_13->setText(QApplication::translate("ALPWidget", "Synch Pulse Width", 0, QApplication::UnicodeUTF8));
        label_14->setText(QApplication::translate("ALPWidget", "PlaneBitNume", 0, QApplication::UnicodeUTF8));
        groupBox_7->setTitle(QApplication::translate("ALPWidget", "Projector Message", 0, QApplication::UnicodeUTF8));
        ProjectorLabel->setText(QApplication::translate("ALPWidget", "TextLabel", 0, QApplication::UnicodeUTF8));
        QuitBtn->setText(QApplication::translate("ALPWidget", "Quit", 0, QApplication::UnicodeUTF8));
        SlaveModeBtn->setText(QApplication::translate("ALPWidget", "SlaveMode", 0, QApplication::UnicodeUTF8));
        masterModeBtn->setText(QApplication::translate("ALPWidget", "masterMode", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class ALPWidget: public Ui_ALPWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ALPEASYPRCWIDGET_H
