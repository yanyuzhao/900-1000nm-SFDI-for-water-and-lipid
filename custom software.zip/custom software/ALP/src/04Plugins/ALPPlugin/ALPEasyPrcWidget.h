
#ifndef ALPEasyPrcWidget_h__
#define ALPEasyPrcWidget_h__
#include "Projector.h"
#include <QWidget>
#include "ui_ALPEasyPrcWidget.h"


class  ALPEasyPrcWidget : public QWidget
{
	Q_OBJECT
public:
	ALPEasyPrcWidget(QWidget* parent = NULL);
	~ALPEasyPrcWidget();

public slots:
	void OnAllocBtnClicked();
	void OnFreeBtnClicked();
	void OnHighRadioClicked(bool value);
	void OnLowRadioClicked(bool value);

	void OnBrightHorizontalSladerValueChanged();

	void OnLoadSequeBtnClicked();
	void OnFreeSequeBtnClicked();
	void OnProjectionBtnClicked();
	void OnStopSequeBtnClicked();

	void OnSequeSettingBtnClicked();
	void OnQuitBtnClicked();

	void OnSlaveModeClicked();
	void ONMaseterModeBtnClicked();
private:
	void InitConnect();
	void SetProjectorReturnCodeMsg( const int retCode);
	// update all dialog elements from data
	void UpdateElements(void);
	// free projector and reset dialog elements
	const int FreeProjector(void);
	// get projector properties and update dialog elements
	const int GetProjectorProperties(void);
	// change synch polarity
	const int SetSyncPolarity();
	// free sequence and reset dialog elements
	const int FreeSequence(void);
	// get sequence properties
	const int GetSequenceProperties(void);
	// change sequence properties
	const int SetSequenceProperties(void);
	// load images and add it to a sequence
	const int LoadSequence(void);
private:
	Ui::ALPWidget* _ui;
	CProjector* _Projector;

	// int member (Radio button) for synch polarity
	int m_iSyncPolarity;
	// int member (Radio button) for the LED type
	int m_iLEDType;
	// int member (Slider) for the LED brightness
	int m_iLedBrightness;
	int _BitPlanes;
};


#endif // GotoPositionWidget_h__
