#ifndef MAINAPP_H
#define MAINAPP_H

#include <QtGui/QMainWindow>
#include "ui_mainapp.h"

class MainApp : public QMainWindow
{
	Q_OBJECT

public:
	MainApp(QWidget *parent = 0, Qt::WFlags flags = 0);
	~MainApp();

private:
	Ui::MainAppClass ui;
};

#endif // MAINAPP_H
