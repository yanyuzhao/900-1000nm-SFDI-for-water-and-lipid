/********************************************************************************
** Form generated from reading UI file 'mainapp.ui'
**
** Created: Thu Jun 25 01:30:54 2020
**      by: Qt User Interface Compiler version 4.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINAPP_H
#define UI_MAINAPP_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QMainWindow>
#include <QtGui/QMenuBar>
#include <QtGui/QStatusBar>
#include <QtGui/QToolBar>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainAppClass
{
public:
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QWidget *centralWidget;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainAppClass)
    {
        if (MainAppClass->objectName().isEmpty())
            MainAppClass->setObjectName(QString::fromUtf8("MainAppClass"));
        MainAppClass->resize(600, 400);
        menuBar = new QMenuBar(MainAppClass);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        MainAppClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainAppClass);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        MainAppClass->addToolBar(mainToolBar);
        centralWidget = new QWidget(MainAppClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        MainAppClass->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(MainAppClass);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainAppClass->setStatusBar(statusBar);

        retranslateUi(MainAppClass);

        QMetaObject::connectSlotsByName(MainAppClass);
    } // setupUi

    void retranslateUi(QMainWindow *MainAppClass)
    {
        MainAppClass->setWindowTitle(QApplication::translate("MainAppClass", "MainApp", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainAppClass: public Ui_MainAppClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINAPP_H
