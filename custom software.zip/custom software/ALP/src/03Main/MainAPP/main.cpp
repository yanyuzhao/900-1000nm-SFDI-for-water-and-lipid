﻿#include "mainapp.h"
#include <QtGui/QApplication>
#include <QtCore/QTextCodec>
#include <QTranslator>
#include <AppliactionFrame/ApplicationFrame.h>
int main(int argc, char *argv[])
{	
	QTextCodec *codec = QTextCodec::codecForName("system");
	QTextCodec::setCodecForCStrings(codec);
	QTextCodec::setCodecForLocale(codec);
	QTextCodec::setCodecForTr(codec);
	QApplication a(argc, argv);
	a.setWindowIcon(QIcon("./Resources/logo.png"));
	Frame::ApplicationFrame* appFrame = new Frame::ApplicationFrame();
	MainApp w;
	QString info = "helloworld";
	std::string stdinfo = info.toStdString();
	w.menuBar()->addMenu("ALP");
	w.menuBar()->addMenu("two");
	w.menuBar()->addMenu("three");
	w.menuBar()->addMenu("four");
	w.menuBar()->addMenu("five");
	w.menuBar()->addMenu("°six");
	appFrame->SetMainWindow(&w);
	std::string Sinfo = "hello world";
	appFrame->InitApplication(Sinfo);
	w.show();
	return a.exec();
}
