#include "mainapp.h"

MainApp::MainApp(QWidget *parent, Qt::WFlags flags)
	: QMainWindow(parent, flags)
{
	ui.setupUi(this);
}

MainApp::~MainApp()
{

}
